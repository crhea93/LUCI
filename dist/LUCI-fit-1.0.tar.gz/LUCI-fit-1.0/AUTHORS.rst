============
Contributors
============

Development Lead
----------------

* Carter Lee Rhea <carter.rhea@umontreal.ca>

Contributors
------------

* Benjamin Vigneron <b.vigeron.1@umontreal.ca>
* Julie Hlavacek-Larrondo <j.larrondo@umontreal.ca>
